module MoneyMachine.MarketHistory where

data MarketHistory = MarketHistory
  {

  }