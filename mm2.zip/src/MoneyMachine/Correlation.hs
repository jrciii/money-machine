module MoneyMachine.Correlation where

import Candle
import Data.Thyme.LocalTime

