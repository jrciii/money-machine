{-# OPTIONS_GHC -F -pgmF hspec-discover #-}
